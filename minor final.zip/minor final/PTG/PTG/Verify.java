import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class Verify
{
	JFrame jf;
	Dimension dim;
	int w,h;
	JFileChooser pkey,keyfile;
	JLabel ver,key,x,y;
	JButton start,match,p,k;
	VerifyMessage vm;
	String pubkey,keyd;
	Verify()
	{
		pubkey="";
		keyd="";
		jf=new JFrame("DIGITAL SIGNATURE VERIFICATION !!!");
		dim=(Toolkit.getDefaultToolkit()).getScreenSize();
		w=(int)(dim.getWidth());
		h=(int)(dim.getHeight());
		jf.setBounds((w/2)-300,(h/2)-300,600,600);
		jf.setResizable(false);
		jf.setLayout(null);
		jf.setDefaultCloseOperation(jf.EXIT_ON_CLOSE);
		jf.setVisible(true);
		initializ();
		configure();
	}
	void initializ()
	{
		x=new JLabel();
		x.setOpaque(true);
		x.setBackground(Color.cyan);
		x.setBounds(100,100,300,35);
		jf.add(x);
		
		y=new JLabel();
		y.setOpaque(true);
		y.setBackground(Color.cyan);
		y.setBounds(x.getX(),x.getY()+x.getHeight()+50,300,35);
		jf.add(y);
		
		p=new JButton("PUBLIC KEY");
		p.setBounds(x.getX()+x.getWidth(),x.getY(),120,35);
		jf.add(p);
		
		k=new JButton("KEY DATA");
		k.setBounds(y.getX()+y.getWidth(),y.getY(),120,35);
		jf.add(k);
		
		ver=new JLabel();
		ver.setOpaque(true);
		ver.setBackground(Color.yellow);
		ver.setBounds(y.getX(),y.getY()+y.getHeight()+40,300,35);
		jf.add(ver);
		
		key=new JLabel();
		key.setOpaque(true);
		key.setBackground(Color.yellow);
		key.setBounds(ver.getX(),ver.getY()+ver.getHeight()+20,300,35);
		jf.add(key);
		
		match=new JButton("VERIFY");
		match.setBounds(ver.getX()+ver.getWidth(),ver.getY(),120,90);
		jf.add(match);
		
		start=new JButton("S T A R T   Q U I Z");
		start.setBounds(key.getX()+100,key.getY()+70,220,90);
		start.setEnabled(false);
		jf.add(start);
		
		pkey=new JFileChooser();
		keyfile=new JFileChooser();
		
		jf.revalidate();
		jf.repaint();
	}
	void configure()
	{
		p.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				int returnVal = pkey.showOpenDialog(jf);
				if (returnVal == JFileChooser.APPROVE_OPTION)
				{
					File file=pkey.getSelectedFile();
					pubkey=file.getAbsolutePath();
					x.setText(pubkey);
				}
			}
		}
		);
		k.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				int returnVal = keyfile.showOpenDialog(jf);
				if (returnVal == JFileChooser.APPROVE_OPTION)
				{
					File file=keyfile.getSelectedFile();
					keyd=file.getAbsolutePath();
					y.setText(keyd);
				}
			}
		}
		);
		match.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				vm=new VerifyMessage(keyd,pubkey);
				if(vm.xx)
				{
					ver.setText("VERIFIED !!!");
					key.setText(vm.genkey);
					start.setEnabled(true);
				}
				else
				{
					ver.setText("NOT VERIFIED !!!");
					key.setText(vm.genkey);
					start.setEnabled(false);
				}
			}
		}
		);
		start.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				QUIZ qz = new QUIZ();
				jf.dispose();
			}
		}
		);
	}
	public static void main(String args[])
	{
		Verify v = new Verify();
	}
}
