import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class QUIZ
{
	JFrame jf;
	JLabel q,stat;
	JRadioButton a,b,c,d;
	JButton sub;
	Dimension dim;
	QuizFetch qf;
	DataSet ds;
	int fin;
	int ql,oq;
	int score;
	int w,h;
	QUIZ()
	{
		fin=1;
		score=0;
		qf=new QuizFetch();
		oq=0;
		ql=qf.arr.length;
		jf=new JFrame("QUIZ !!!");
		dim=(Toolkit.getDefaultToolkit()).getScreenSize();
		w=(int)(dim.getWidth());
		h=(int)(dim.getHeight());
		jf.setBounds((w/2)-300,(h/2)-300,600,600);
		jf.setResizable(false);
		jf.setLayout(null);
		jf.setDefaultCloseOperation(jf.EXIT_ON_CLOSE);
		jf.setVisible(true);
		initializ();
	}
	void initializ()
	{
		q=new JLabel();
		q.setOpaque(true);
		q.setBackground(Color.blue);
		q.setForeground(Color.orange);
		q.setFont(new Font("Comic Sans MS",0,16));
		q.setBounds(100,80,400,150);
		jf.add(q);
		
		a=new JRadioButton();
		a.setOpaque(true);
		a.setBackground(Color.cyan);
		a.setBounds(q.getX(),q.getY()+q.getHeight()+15,400,25);
		jf.add(a);
		
		b=new JRadioButton();
		b.setOpaque(true);
		b.setBackground(Color.cyan);
		b.setBounds(a.getX(),a.getY()+a.getHeight()+15,400,25);
		jf.add(b);
		
		c=new JRadioButton();
		c.setOpaque(true);
		c.setBackground(Color.cyan);
		c.setBounds(b.getX(),b.getY()+b.getHeight()+15,400,25);
		jf.add(c);
		
		d=new JRadioButton();
		d.setOpaque(true);
		d.setBackground(Color.cyan);
		d.setBounds(c.getX(),c.getY()+c.getHeight()+15,400,25);
		jf.add(d);
		
		sub=new JButton("S U B M I T");
		sub.setBounds(d.getX()+130,d.getY()+d.getHeight()+25,140,25);
		jf.add(sub);
		
		stat=new JLabel();
		stat.setOpaque(true);
		stat.setBackground(Color.yellow);
		stat.setBounds(q.getX()+250,q.getY()-35,100,25);
		jf.add(stat);
		
		jf.revalidate();
		jf.repaint();
		
		configure();
		update();
	}
	void update()
	{
		oq++;
		if(oq>ql)
		{
			fin=2;
			sub.setText("Final Submit");
			q.setText("");
			a.setText("");
			b.setText("");
			c.setText("");
			d.setText("");
			stat.setText("");
			return;
		}
		stat.setText(oq+"/"+ql);
		ds=qf.arr[oq-1];
		q.setText(ds.q);
		a.setText(ds.a);
		b.setText(ds.b);
		c.setText(ds.c);
		d.setText(ds.d);
	}
	void configure()
	{
		ButtonGroup bg=new ButtonGroup();
		bg.add(a);
		bg.add(b);
		bg.add(c);
		bg.add(d);
		sub.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String ans;
				if(fin==1)
				{
					if(a.isSelected())
					{
						ans=ds.a;
					}
					else if(b.isSelected())
					{
						ans=ds.b;
					}
					else if(c.isSelected())
					{
						ans=ds.c;
					}
					else if(d.isSelected())
					{
						ans=ds.d;
					}
					else
					{
						ans="";
					}
					if(ans.equals(ds.r))
					{
						score++;
					}
					bg.clearSelection();
					update();
				}
				else if(fin==2)
				{
					jf.remove(a);
					jf.remove(b);
					jf.remove(c);
					jf.remove(d);
					q.setText("SCORE : "+score+" OUT OF "+ql);
					fin=3;
					jf.revalidate();
					jf.repaint();
				}
			}
		}
		);
	}
}
