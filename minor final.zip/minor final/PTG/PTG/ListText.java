import java.io.*;
import java.util.*;
class ListText
{
	LinkedList<String> fileToList(String dir)
	{
		LinkedList<String> link = new LinkedList<String>();
		File chk;
		String str;
		BufferedReader br;
		try
		{
			chk = new File(dir);
			if(!(chk.exists()&&chk.isFile()))
			{
				return null;
			}
			br=new BufferedReader(new FileReader(dir));
			while((str=br.readLine())!=null)
			{
				link.add(str);
			}
			br.close();
		}
		catch(IOException e)
		{
			System.out.println("ERROR !!!");
			return null;
		}
		return link;
	}
}
