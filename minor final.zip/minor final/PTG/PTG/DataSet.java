class DataSet
{
	String q;
	String a,b,c,d;
	String r;
	DataSet()
	{
	}
	DataSet(String q1,String a1,String b1,String c1,String d1,String r1)
	{
		q=q1;
		a=a1;
		b=b1;
		c=c1;
		d=d1;
		r=r1;
	}
	void setQ(String q1)
	{
		q=q1;
	}
	void setA(String a1)
	{
		a=a1;
	}
	void setB(String b1)
	{
		b=b1;
	}
	void setC(String c1)
	{
		c=c1;
	}
	void setD(String d1)
	{
		d=d1;
	}
	void setR(String r1)
	{
		r=r1;
	}
}
