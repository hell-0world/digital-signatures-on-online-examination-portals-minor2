import java.util.*;
class QuizFetch
{
	ListText lt;
	DataSet pre;
	DataSet arr[];
	String dir;
	String data[];
	int l;
	LinkedList<String> fdata;
	LinkedList<DataSet> ds;
	QuizFetch()
	{
		int i=0;
		dir=System.getProperty("user.dir").toString()+"\\quiz_data.txt";
		lt=new ListText();
		ds=new LinkedList<DataSet>();
		fdata=lt.fileToList(dir);
		l=fdata.size();
		data=new String[l];
		for(String str : fdata)
		{
			data[i++]=str.trim();
		}
		process();
	}
	void process()
	{
		int i,j,op;
		char ff;
		op=1;
		for(i=0;i<l;i++)
		{
			if(data[i].length()>5&&data[i].charAt(0)=='^')
			{
				op=1;
				pre=new DataSet();
				pre.setQ(data[i].substring(1).trim());
			}
			else if(op==1&&data[i].length()>1)
			{
				ff=data[i].charAt(0);
				if(ff=='@')
				{
					pre.setA(data[i].substring(1).trim());
					op=2;
				}
				else if(ff=='#')
				{
					pre.setA(data[i].substring(1).trim());
					pre.setR(data[i].substring(1).trim());
					op=2;
				}
			}
			else if(op==1&&data[i].length()>1)
			{
				ff=data[i].charAt(0);
				if(ff=='@')
				{
					pre.setA(data[i].substring(1).trim());
					op=2;
				}
				else if(ff=='#')
				{
					pre.setA(data[i].substring(1).trim());
					pre.setR(data[i].substring(1).trim());
					op=2;
				}
			}
			else if(op==2&&data[i].length()>1)
			{
				ff=data[i].charAt(0);
				if(ff=='@')
				{
					pre.setB(data[i].substring(1).trim());
					op=3;
				}
				else if(ff=='#')
				{
					pre.setB(data[i].substring(1).trim());
					pre.setR(data[i].substring(1).trim());
					op=3;
				}
			}
			else if(op==3&&data[i].length()>1)
			{
				ff=data[i].charAt(0);
				if(ff=='@')
				{
					pre.setC(data[i].substring(1).trim());
					op=4;
				}
				else if(ff=='#')
				{
					pre.setC(data[i].substring(1).trim());
					pre.setR(data[i].substring(1).trim());
					op=4;
				}
			}
			else if(op==4&&data[i].length()>1)
			{
				ff=data[i].charAt(0);
				if(ff=='@')
				{
					pre.setD(data[i].substring(1));
					ds.add(pre);
					op=0;
				}
				else if(ff=='#')
				{
					pre.setD(data[i].substring(1));
					pre.setR(data[i].substring(1));
					ds.add(pre);
					op=0;
				}
			}
		}
		i=0;
		arr=new DataSet[ds.size()];
		for(DataSet str : ds)
		{
			arr[i++]=str;
		}
	}
	void display()
	{
		int i=1;
		for(DataSet str : ds)
		{
			System.out.println(i++);
			System.out.println("Question : "+str.q);
			System.out.println("Option A : "+str.a);
			System.out.println("Option B : "+str.b);
			System.out.println("Option C : "+str.c);
			System.out.println("Option D : "+str.d);
			System.out.println("Correct is : "+str.r);
		}
	}
}
