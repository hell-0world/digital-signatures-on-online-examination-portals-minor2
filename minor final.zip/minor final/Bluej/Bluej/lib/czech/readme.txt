Ceska lokalizace pro BlueJ 3.0
===============================

Lokalizace pouziva kodovani ASCII

Verze 3.0 ze dne 27.3.2010.

Lokalizaci vytvorili Petr Skoda a Rudolf Pecinovsky.


Aktualizace a dalsi informace ziskate na adrese:

  http://vyuka.pecinovsky.cz

pripadne na mailu

  rudolf@pecinovsky.cz
