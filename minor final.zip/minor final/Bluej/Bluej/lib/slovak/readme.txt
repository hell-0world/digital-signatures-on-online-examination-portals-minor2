﻿Slovenská lokalizácia pre BlueJ 3.0
===================================

Verzia 1.0 zo dňa 22.9.2010.


Lokalizáciu vytvorili Roman Horváth a Andrea Hrnčiariková. Prvý autor vytvoril hrubú verziu prekladu, ktorú revidovala druhá spoluautorka.

Lokalizácia bola pôvodne inšpirovaná českým prekladom z dielne autorov Petra Škodu (http://www.rdv.vslib.cz/skodak) a Rudolfa Pecinovského (http://vyuka.pecinovsky.cz) zo dňa 11.1.2006 pre verziu BlueJ 2.1.2.

Od začatia prekladu (koniec septembra 2009) prešla slovenská verzia lokalizácie výraznými zmenami a priklonila sa viac k pôvodnému anglickému zneniu. Českým autorom v každom prípade ďakujeme za inšpiráciu a poskytnutie „štartovacej“ verzie.


Aktualizácie a ďalšie informácie získate na adrese:

  * http://cec.truni.sk/horvath/personal.php?get_bluej_trans
